<p dir="rtl" align="center"><span style="font-family: David;"><span style="font-size: x-large;"><span lang="he-IL"><span style="text-decoration: underline;">כרטיס עובד &ndash; טופס </span></span></span></span>101</p>
<p dir="rtl" align="center"><span style="font-family: David;"><span style="font-size: x-large;"><span lang="he-IL"><span style="text-decoration: underline;">טופס </span></span></span></span>2<span style="font-family: David;"><span style="font-size: x-large;"><span lang="he-IL"><span style="text-decoration: underline;"><span style="font-size: medium;">א</span></span></span></span></span></p>
<p dir="rtl" align="center"><span style="font-family: David;"><span style="font-size: small;"><span lang="he-IL">ובקשה להקלה ולתיאום מס על</span></span></span>-<span style="font-family: David;"><span style="font-size: small;"><span lang="he-IL">ידי המעביד </span></span></span>( <span style="font-family: David;"><span style="font-size: small;"><span lang="he-IL">ט</span></span></span>-8)</p>
<p class="western" dir="rtl" style="font-weight: normal;" align="center"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לפי תקנות מס הכנסה ומס מעסיקים </span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ניכוי ממשכורת ומשכר עבודה ותשלום מס מעסיקים</span></span></span>), <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">התשנ</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ג </span></span></span>- 1993</p>
<h1 class="western" dir="rtl"><span style="font-family: David;"><span style="font-size: large;"><span lang="he-IL">שנת המס </span></span></span>__________</h1>
<p class="western" dir="rtl" align="center">&nbsp;</p>
<table dir="rtl" width="568" cellspacing="0" cellpadding="7">
<tbody>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="552">
<p class="western" align="center"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">טופס זה ימולא על</span></span></span>-<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ידי כל עובד עם תחילת עבודתו</span></span></span>, <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">וכן בתחילת כל שנת מס </span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">אא</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">כ הנציב אישר אחרת</span></span></span>) <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">הטופס מהווה אסמכתא למעביד למתן הקלות במס ולעריכת תאומי מס בחישוב משכורת העובד</span></span></span>.</p>
<p class="western" style="font-weight: normal;" align="center"><strong>(</strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;"><strong>ראה הסברים </strong></span></span></span><strong>(</strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;"><strong>לפי מספרים</strong></span></span></span><strong>) </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;"><strong>מעבר לדף</strong></span></span></span><strong>)</strong></p>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>א</strong></span></span></span><strong>. </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>פרטי </strong></span><span style="font-size: xx-small;">המעביד </span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">למילוי ע</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">י המעביד</span></span></span>)</p>
<table dir="rtl" width="568" cellspacing="0" cellpadding="7">
<tbody>
<tr valign="top">
<td style="border-top: 1px solid #00000a; border-bottom: none; border-left: 1px solid #00000a; border-right: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="127">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>שם</strong></span></span></span></p>
</td>
<td style="border-top: 1px solid #00000a; border-bottom: none; border-left: 1px solid #00000a; border-right: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="128">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>כתובת</strong></span></span></span></p>
</td>
<td style="border-top: 1px solid #00000a; border-bottom: none; border-left: 1px solid #00000a; border-right: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="128">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>מס</strong></span></span></span><strong>' </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>טלפון</strong></span></span></span></p>
</td>
<td style="border-top: 1px solid #00000a; border-bottom: none; border-left: 1px solid #00000a; border-right: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="127">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>תיק ניכויים</strong></span></span></span></p>
</td>
</tr>
<tr valign="top">
<td style="border-top: none; border-bottom: 1px solid #00000a; border-left: 1px solid #00000a; border-right: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="127">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>משרד החינוך</strong></span></span></span></p>
</td>
<td style="border-top: none; border-bottom: 1px solid #00000a; border-left: 1px solid #00000a; border-right: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="128">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>השלושה </strong></span></span></span><strong>2</strong></p>
</td>
<td style="border-top: none; border-bottom: 1px solid #00000a; border-left: 1px solid #00000a; border-right: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="128">
<p class="western">&nbsp;</p>
</td>
<td style="border-top: none; border-bottom: 1px solid #00000a; border-left: 1px solid #00000a; border-right: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="127">
<p class="western" style="font-weight: normal;"><strong>941001729</strong></p>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>ב</strong></span></span></span><strong>. </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>פרטי העובד</strong></span></span></span></p>
<table dir="rtl" width="568" cellspacing="0" cellpadding="7">
<tbody>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="111" height="42">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מס</span></span></span>' <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">זהות</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="4" width="298">
<h2 class="western"><span style="font-family: David;"><span style="font-size: small;"><span lang="he-IL"><span style="font-weight: normal;">שם משפחה שם פרטי</span></span></span></span></h2>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="51">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תאריך לידה</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="50">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תאריך עליה</span></span></span></p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="215" height="17">
<h3 class="western"><span style="font-family: David;"><span style="font-size: large;"><span lang="he-IL"><span style="font-size: small;"><span style="font-weight: normal;">כתובת פרטית</span></span></span></span></span></h3>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="43">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="78">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="46">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="3" width="115">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">טלפון</span></span></span></p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="215">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">רחוב</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שכונה</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="43">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מס</span></span></span>'</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="78">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">עיר</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ישוב</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="46">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מיקוד</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="3" width="115">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">קידומת</span></span></span></p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" rowspan="2" width="111">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מין</span></span></span></p>
<p class="western" style="font-weight: normal;"><a name="סימון1"></a><a name="סימון2"></a> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">זכר </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">נקבה</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="4" rowspan="2" width="298">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מצב משפחתי</span></span></span></p>
<p class="western" style="font-weight: normal;"><a name="סימון3"></a> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">רווק</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ה </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">נשוי</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אה </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">גרוש</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ה </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אלמן</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ה</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="62">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תושב ישראל</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" rowspan="2" width="39">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">מס</span></span></span>' <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ילדים</span></span></span></p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">שלא מלאו להם </span></span></span>19 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">שנה</span></span></span></p>
<p class="western" style="font-weight: normal;">________</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="62">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">כן </span></span></span><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לא</span></span></span></p>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>ג</strong></span></span></span><strong>. </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>פרטים על ילדי שבשנת המס טרם מלאו להם </strong></span></span></span><strong>19 </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>שנה</strong></span></span></span><strong>. </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;"><strong>סמן </strong></span></span></span><strong>V </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;"><strong>בטור המתאים ליד שם הילד הנמצא בחזקתך</strong></span></span></span></p>
<table dir="rtl" width="568" cellspacing="0" cellpadding="7">
<tbody>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="7">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="62">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>שם</strong></span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="80">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>מס</strong></span></span></span><strong>' </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>זהות</strong></span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="78">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>תאריך לידה</strong></span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="8">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="71">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>שם</strong></span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="81">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>מס</strong></span></span></span><strong>' </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>זהות</strong></span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="68">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>תאריך לידה</strong></span></span></span></p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="7">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="62">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="80">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="78">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="8">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="71">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="81">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="68">
<p class="western">&nbsp;</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="7">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="62">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="80">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="78">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="8">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="71">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="81">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="68">
<p class="western">&nbsp;</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="7">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="62">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="80">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="78">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="8">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="71">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="81">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="68">
<p class="western">&nbsp;</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="7">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="62">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="80">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="78">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="8">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="71">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="81">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="68">
<p class="western">&nbsp;</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="7">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="62">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="80">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="78">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="8">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="71">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="81">
<p class="western">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="68">
<p class="western">&nbsp;</p>
</td>
</tr>
</tbody>
</table>
<p dir="rtl"><span style="font-family: David;"><span style="font-size: large;"><span lang="he-IL">ד</span></span></span>. <span style="font-family: David;"><span style="font-size: large;"><span lang="he-IL">פרטים על הכנסותי ממעביד זה</span></span></span></p>
<table dir="rtl" width="568" cellspacing="0" cellpadding="7">
<tbody>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="253">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אני מקבל</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ת </span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ראה הסברים מעבר לדף</span></span></span>)</p>
<p class="western" style="font-weight: normal;">&nbsp;</p>
<p class="western" style="font-weight: normal;"><a name="סימון4"></a> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכורת חודש </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכורת חלקית </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">קיצבה</span></span></span></p>
<p class="western" style="font-weight: normal;">&nbsp;</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכורת נוספת </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שכר עבודה</span></span></span></p>
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="81">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תאריך תחילה</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="109">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תאריך סיום</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="68">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מס חודשי עבודה </span></span></span></p>
<p class="western" style="font-weight: normal;">(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בשנת מס</span></span></span>)</p>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>ה</strong></span></span></span><strong>. </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>פרטים על הכנסות אחרות</strong></span></span></span></p>
<table dir="rtl" width="570" cellspacing="0" cellpadding="7">
<tbody>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="554">
<p class="western" style="font-weight: normal;"><a name="סימון5"></a> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אין לי הכנסות נוספות </span></span></span></p>
<p class="western">&nbsp;</p>
</td>
</tr>
<tr>
<td style="border-top: 1px solid #000001; border-bottom: 1px solid #00000a; border-left: 1px solid #00000a; border-right: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="554" height="55">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">יש לי הכנסות אחרות כמפורט להלן</span></span></span>:</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכורת חודש </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכורת חלקית </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">קיצבה</span></span></span></p>
<p class="western" style="font-weight: normal;">&nbsp;</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכורת נוספת </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שכר עבודה </span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">עובד יומי</span></span></span>) <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ממקור אחר</span></span></span>_____________</p>
<p class="western" style="font-weight: normal;">&nbsp;</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">איני מקבל</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ת את נקודות הזיכוי ו</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">או מדרגות המס בהכנסתי האחרת </span></span></span>(7)</p>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>ו</strong></span></span></span><strong>. </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>פרטים על בן</strong></span></span></span><strong>/</strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>בת הזוג</strong></span></span></span></p>
<table dir="rtl" width="570" cellspacing="0" cellpadding="7">
<tbody>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="127">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL">מס</span></span>' <span style="font-family: David;"><span lang="he-IL">זהות </span></span>(9 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ספרות</span></span></span>)</p>
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="128">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שם משפחה</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="93">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שם פרטי</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="81">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תאריך לידה</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="70">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תאריך עליה</span></span></span></p>
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="5" valign="top" width="554">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אין לבן</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בת הזוג כל הכנסה </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">יש לבן</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בת הזוג הכנסה מ</span></span></span>: <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">עבודה</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">עסק </span></span></span> <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">הכנסה חייבת אחרת לרבות קיצבה</span></span></span></p>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>ז</strong></span></span></span><strong>. </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>שינויים במהלך השנה </strong></span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">כולל שינויים הקשורים לבקשה להקלה בחישוב המס מעבר לדף</span></span></span>)</p>
<table dir="rtl" width="568" cellspacing="0" cellpadding="7">
<tbody>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="102">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL">תאריך השינוי</span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="317">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL">פרטי השינוי</span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="106">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL">חתימת העובד</span></span></p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="102">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="317">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="106">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="102">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="317">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="106">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="102">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="317">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="106">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>ח</strong></span></span></span><strong>. </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>אני מבקש</strong></span></span></span><strong>/</strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>ת פטור או זיכוי ממס מהסיבות הבאות </strong></span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">סמן </span></span></span>V <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">בריבוע המתאים</span></span></span>)</p>
<p class="western" dir="rtl" style="font-weight: normal;">&nbsp;</p>
<p class="western" dir="rtl" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="text-decoration: underline;"><span style="font-size: x-large;"><strong>טופס </strong></span></span></span></span><span style="font-size: x-large;"><strong>2</strong></span><span style="font-family: David;"><span lang="he-IL"><span style="text-decoration: underline;"><strong>ב</strong></span></span></span></p>
<p class="western" dir="rtl" style="font-weight: normal;">&nbsp;</p>
<table dir="rtl" width="608" cellspacing="0" cellpadding="7">
<tbody>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">1. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אני תושב</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ת ישראל</span></span></span></p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">2. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אני נכה </span></span></span>100% / <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">עיוור</span></span></span>, <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מצורף</span></span></span>: <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אישור ממשרד הביטחון</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">האוצר</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">פקיד שומה</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תעודת עיוור שהוצאה לאחר </span></span></span>1.1.94</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">3. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אני תושב קבוע</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ה בישוב מיוחד</span></span></span>/ <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">באיזור פיתוח מתאריך </span></span></span>_____________</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שם הישוב </span></span></span>_______________________ <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">מצורף אישור של הרשות המקומית או של הועד המקומי</span></span></span></p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">4. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אני עולה חדש מתאריך </span></span></span>_____________</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לא היתה לי הכנסה בישראל מתחילת שנת המס הנוכחית עד תאריך </span></span></span>________________</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">מי שהיתה לו הכנסה או שתקופת זכאותו </span></span></span>(42 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">חודש</span></span></span>) <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">אינה רצופה בשל שירות חובה בצה</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ל</span></span></span>, <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">לימודים על תיכוניים או יציאה לחו</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ל &ndash; יפנה לפקיד השומה</span></span></span>.</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">5. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בגין בן</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בת זוגי המתגורר</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ת עימי ואין לו</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לה הכנסות בשנת המס</span></span></span>.</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">6. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בגין משפחה חד הורית</span></span></span>.</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">7. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בגין ילדי שבחזקתי </span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ימולא רק ע</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">י אשה או גבר חד הורי</span></span></span>) <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">המפורטים בחלק ג</span></span></span>'</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">מס</span></span></span>' <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ילדים שנולדו בשנת המס </span></span></span>__________ <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">מס</span></span></span>' <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ילדים שימלאו להם </span></span></span>18 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">שנה בשנת המס </span></span></span>_____ <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">מס</span></span></span>' <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ילדים אחרים </span></span></span>&shy;&shy;&shy;&shy;&shy;&shy;_________</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">8. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בגין ילדי שאינם בחזקתי המפורטים בחלק ג</span></span></span>' <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ואני משתתף בכלכלתם</span></span></span>.</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">9. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בגין מזונות לבן</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">בת זוג לשעבר </span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ימולא ע</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">י מי שנישא בשנית</span></span></span>) ( <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מצורף פסק דין</span></span></span>).</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">10. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מלאו לי </span></span></span>16 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שנים וטרם מלאו לי </span></span></span>18 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שנים</span></span></span>.</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;">11. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אני חייל משוחרר</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ת</span></span></span>/ <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שרתתי בשירות לאומי &ndash; רק למשתחררים בין ה</span></span></span>- 1.1.94 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ל</span></span></span>- 27.4.94</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">ע</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">פ חוק תקופת שירות חובה לחייל</span></span></span>- <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">מעל שנתיים</span></span></span>, <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">לחיילת ולמשרתת בשירות לאומי &ndash; מעל שנה</span></span></span>.</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תאריך הגיוס</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תחילת השירות </span></span></span>_____________ <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">תאריך השחרור</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">סיום שירות </span></span></span>_______________</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">מצורף צילום של תעודת השחרור</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">סיום שירות</span></span></span>. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">במקרה של תקופת שירות אחרת &ndash; יפנה לפקיד השומה</span></span></span>.</p>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>ט</strong></span></span></span><strong>. </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>אני מבקש</strong></span></span></span><strong>/</strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: large;"><strong>ת תיאום מס מהסיבות הבאות </strong></span></span></span>(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">סמן </span></span></span>V <span style="font-family: David;"><span lang="he-IL"><span style="font-size: xx-small;">בריבוע המתאים</span></span></span>)</p>
<table dir="rtl" width="609" cellspacing="0" cellpadding="7">
<tbody>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="10" valign="top" width="593" height="47">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לא היתה לי הכנסה מתחילת שנת המס הנוכחית עד לתחילת עבודתי אצל מעביד זה</span></span></span>.</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">הערות </span></span></span>1. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">יש להמציא הוכחה</span></span></span>, <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">כגון</span></span></span>: <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אישור משטרת הגבולות בגין שהייה בחו</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ל</span></span></span>, <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אישור מחלה וכיו</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">ב</span></span></span>. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">העדר הוכחה יש לפנות לפקיד השומה</span></span></span></p>
<p class="western" style="font-weight: normal;">2. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">דמי לידה ודמי אבטלה הינם הכנסה חייבת</span></span></span></p>
<p class="western" style="font-weight: normal;">2. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">יש לי הכנסה נוספת ממשכורת </span></span></span>/ <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">קצבה כמפורט להלן</span></span></span>:</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="4" width="244">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>המעביד </strong></span></span></span><strong>/ </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>משלם הקצבה </strong></span></span></span><strong>/ </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>מקור אחר</strong></span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="118">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">סוג ההכנסה</span></span></span></p>
<p class="western" style="font-weight: normal;">(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכורת</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">קצבה</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אחר</span></span></span>)</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="3" width="128">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">הכנסה חודשית</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="62">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">המס שנוכה</span></span></span></p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="66">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שם</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="3" width="163">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">כתובת</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="118">
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">מספר תיק ניכויים</span></span></span></p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="4" width="203">
<p class="western" style="font-weight: normal;">(<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לפי התלושים</span></span></span>)</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="66">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="67">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="82">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="118">
<p class="western" style="font-weight: normal;" align="left">9</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="62">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="52">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="62">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="66">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="67">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="82">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="118">
<p class="western" style="font-weight: normal;" align="left">9</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="62">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="52">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="62">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
</tr>
<tr valign="top">
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="66">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="67">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="82">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="118">
<p class="western" style="font-weight: normal;" align="left">9</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="62">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" width="52">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="2" width="62">
<p class="western" style="font-weight: normal;">&nbsp;</p>
</td>
</tr>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" colspan="10" valign="top" width="593">
<p class="western" style="font-weight: normal;">3. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">פקיד השומה אישר תיאום לפי אישור מצורף</span></span></span></p>
</td>
</tr>
</tbody>
</table>
<p dir="rtl"><span style="font-family: David;"><span style="font-size: large;"><span lang="he-IL">י</span></span></span>. <span style="font-family: David;"><span style="font-size: large;"><span lang="he-IL">הצהרה</span></span></span></p>
<table dir="rtl" width="608" cellspacing="0" cellpadding="7">
<tbody>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="592">
<p class="western" style="font-weight: normal;" align="center"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>אני מצהיר</strong></span></span></span><strong>/</strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>ה כי הפרטים שמסרתי בטופס זה הינם מלאים ונכונים</strong></span></span></span><strong>.</strong></p>
<p class="western" style="font-weight: normal;" align="center"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>ידוע לי שהשמטה או מסירת פרטים לא נכונים הינה עבירה על פקודת מס הכנסה</strong></span></span></span><strong>.</strong></p>
<p class="western" style="font-weight: normal;" align="center"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>אני מתחייב</strong></span></span></span><strong>/</strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>ת להודיע למעביד על כל שינוי שיחול בפרטי האישיים ובפרטים דלעיל תוך שבוע ימים מתאריך השינוי</strong></span></span></span><strong>.</strong></p>
<p class="western" align="center">&nbsp;</p>
<h4 class="western">________________ _______________________</h4>
<h4 class="western"><span style="font-family: David;"><span style="font-size: small;"><span lang="he-IL">תאריך חתימת המבקש</span></span></span></h4>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl">&nbsp;</p>
<table dir="rtl" width="568" cellspacing="0" cellpadding="7">
<tbody>
<tr>
<td style="border: 1px solid #00000a; padding: 0in 0.08in 0in 0.08in;" valign="top" width="552">
<p class="western" style="font-weight: normal;" align="center"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>דברי הסבר למילוי טופס </strong></span></span></span><strong>0101</strong></p>
<p class="western" style="font-weight: normal;">&nbsp;</p>
<p class="western" style="font-weight: normal;">"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>עובד</strong></span></span></span>" <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לרבות מקבל קיצבה</span></span></span>. "<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>מעביד</strong></span></span></span>" <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לרבות משלם </span><span style="font-size: small;"><strong>קיצבה</strong></span></span></span>. "<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכורת</span></span></span>" <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לרבות קיצבה</span></span></span>. "<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>עבודה</strong></span></span></span>" <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">לרבות קבלת קיצבה</span></span></span>.</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>משכורת חודש</strong></span><span style="font-size: small;"> &ndash; משכורת בעד עבודה של לא פחות מ</span></span></span>- 18 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">יום בחודש ויותר מ</span></span></span>- 5 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שעות בכל יום</span></span></span>.</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>משכורת נוספת</strong></span><span style="font-size: small;"> &ndash; משכורת בעד עבודה של לא פחות מ</span></span></span>- 18 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">יום בחודש ויותר מ</span></span></span>-5 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שעות בכל יום</span></span></span>, <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">נוסף למשכורת חודש ו</span></span></span>/<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">או בנוסף לקיצבה החייבת במס ממקום אחר</span></span></span>. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">העובד רשאי לבחור את המקום העבודה בו תחשב משכורתו כ</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכורת נוספת</span></span></span>"</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>משכורת חלקית</strong></span><span style="font-size: small;"> &ndash; משכורת בעד עבודה במשך </span></span></span>5 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שעות ביום בכל יום או משכורת בעד עבודה במשך יותר מ</span></span></span>-5 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שעות ביום אך לא יותר מ</span></span></span>-8 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שעות בשבוע</span></span></span>. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>ממשכורת חלקית ינוכה מס בשיעור של </strong></span></span></span><strong>50% </strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>אא</strong></span></span></span><strong>"</strong><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>כ זו הכנסה יחידה שאז ינוכה מס לפי לוח ניכויים</strong></span></span></span><strong>.</strong></p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>שכר עבודה</strong></span><span style="font-size: small;"> &ndash; ממשכורת בעד עבודה של יותר מ</span></span></span>- 5 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">שעות ביום אך לפחות מ</span></span></span>-18 <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">יום בחודש</span></span></span>. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">משכר עבודה ינוכה מס לפי לוח יומי אלא אם כן זו הכנסה יחידה שאז ינוכה מב לפי לוח ניכויים</span></span></span>.</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;"><strong>קיצבה</strong></span><span style="font-size: small;"> &ndash; מקיצה שהיא הכנסה יחידה ינוכה מס לפי לוח ניכויים</span></span></span>. <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אם יש הכנסות נוספות &ndash; ינוכה מס בשיעור </span></span></span>48% <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אא</span></span></span>"<span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">כ מקבל הקיצבה הגיע לגיל פרישה שאז ינוכה מס לפי התקנות</span></span></span>.</p>
<p class="western" style="font-weight: normal;"><span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אם העובד לא מילא משבצת זו &ndash; המעביד מנוע מלנכות מס לפי לוח הניכויים ויש לנכות מס מירבי לפי התקנות</span></span></span>, <span style="font-family: David;"><span lang="he-IL"><span style="font-size: small;">אלא אם הומצא אישור פקיד השומה לתיאום מס</span></span></span>.</p>
<p class="western">&nbsp;</p>
</td>
</tr>
</tbody>
</table>
<p class="western" dir="rtl">&nbsp;</p>
<p class="western" dir="rtl" style="font-weight: normal;">&nbsp;</p>
<p>&nbsp;</p>