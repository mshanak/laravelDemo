<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class News extends Model
{
    //protected $table="dfjkhdskj"
}



/**

1.databse table
2. model
3.controller 
4. vieews
5. router
*/